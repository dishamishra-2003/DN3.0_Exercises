// DependencyInjectionExample.java

interface CustomerRepository {
    String findCustomerById(String id);
}

class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public String findCustomerById(String id) {
        if (id.equals("1234")) {
            return "John Doe";
        }
        return "Customer not found";
    }
}

class CustomerService {
    private final CustomerRepository customerRepository;

    
    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public String getCustomerName(String id) {
        return customerRepository.findCustomerById(id);
    }
}

public class DependencyInjectionExample {
    public static void main(String[] args) {
        
        CustomerRepository repository = new CustomerRepositoryImpl();

        
        CustomerService service = new CustomerService(repository);

        
        String customerName = service.getCustomerName("1234");
        System.out.println("Customer Name: " + customerName);

        
        String nonExistingCustomerName = service.getCustomerName("5678");
        System.out.println("Customer Name: " + nonExistingCustomerName);
    }
}
