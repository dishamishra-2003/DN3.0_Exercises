public class Computer {
    // Attributes of the Computer
    private String CPU;
    private String RAM;
    private String storage;
    private String GPU;
    private String operatingSystem;

    // Private constructor to prevent direct instantiation
    private Computer(Builder builder) {
        this.CPU = builder.CPU;
        this.RAM = builder.RAM;
        this.storage = builder.storage;
        this.GPU = builder.GPU;
        this.operatingSystem = builder.operatingSystem;
    }

    // Static nested Builder class
    public static class Builder {
        private String CPU;
        private String RAM;
        private String storage;
        private String GPU;
        private String operatingSystem;

        // Method to set CPU
        public Builder setCPU(String CPU) {
            this.CPU = CPU;
            return this;
        }

        // Method to set RAM
        public Builder setRAM(String RAM) {
            this.RAM = RAM;
            return this;
        }

        // Method to set storage
        public Builder setStorage(String storage) {
            this.storage = storage;
            return this;
        }

        // Method to set GPU
        public Builder setGPU(String GPU) {
            this.GPU = GPU;
            return this;
        }

        // Method to set operating system
        public Builder setOperatingSystem(String operatingSystem) {
            this.operatingSystem = operatingSystem;
            return this;
        }

        // Build method to create an instance of Computer
        public Computer build() {
            return new Computer(this);
        }
    }

    @Override
    public String toString() {
        return "Computer [CPU=" + CPU + ", RAM=" + RAM + ", storage=" + storage +
               ", GPU=" + GPU + ", operatingSystem=" + operatingSystem + "]";
    }

    // Main method to test the Builder pattern
    public static void main(String[] args) {
        // Create different configurations of Computer using the Builder pattern
        Computer gamingComputer = new Computer.Builder()
                .setCPU("Intel Core i9")
                .setRAM("32GB")
                .setStorage("1TB SSD")
                .setGPU("NVIDIA RTX 3080")
                .setOperatingSystem("Windows 10")
                .build();

        Computer officeComputer = new Computer.Builder()
                .setCPU("Intel Core i5")
                .setRAM("16GB")
                .setStorage("512GB SSD")
                .setOperatingSystem("Windows 10")
                .build();

        Computer budgetComputer = new Computer.Builder()
                .setCPU("AMD Ryzen 3")
                .setRAM("8GB")
                .setStorage("256GB SSD")
                .build();

        // Print out the configurations
        System.out.println(gamingComputer);
        System.out.println(officeComputer);
        System.out.println(budgetComputer);
    }
}
