public class EmployeeManagementSystem {

    // Inner Employee class
    public static class Employee {
        private String employeeId;
        private String name;
        private String position;
        private double salary;

        public Employee(String employeeId, String name, String position, double salary) {
            this.employeeId = employeeId;
            this.name = name;
            this.position = position;
            this.salary = salary;
        }

        public String getEmployeeId() {
            return employeeId;
        }

        public String getName() {
            return name;
        }

        public String getPosition() {
            return position;
        }

        public double getSalary() {
            return salary;
        }

        @Override
        public String toString() {
            return "Employee{" +"employeeId='" + employeeId + '\'' +", name='" + name + '\'' +", position='" + position + '\'' +", salary=" + salary +'}';
        }
    }

    private Employee[] employees;
    private int size;
    
    public EmployeeManagementSystem(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }

    // Add employee
    public void addEmployee(Employee employee) {
        if (size < employees.length) {
            employees[size++] = employee;
        } else {
            System.out.println("Array is full. Cannot add more employees.");
        }
    }

    // Search employee by ID
    public Employee searchEmployeeById(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                return employees[i];
            }
        }
        return null;
    }

    // Traverse all employees
    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    // Delete employee by ID
    public void deleteEmployeeById(String employeeId) {
        int indexToRemove = -1;
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                indexToRemove = i;
                break;
            }
        }
        if (indexToRemove != -1) {
            for (int i = indexToRemove; i < size - 1; i++) {
                employees[i] = employees[i + 1];
            }
            employees[size - 1] = null; // Clear the last element
            size--;
        } else {
            System.out.println("Employee not found.");
        }
    }

    // Main method for testing
    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(5);

        // Adding employees
        ems.addEmployee(new Employee("E001", "John Doe", "Manager", 75000));
        ems.addEmployee(new Employee("E002", "Jane Smith", "Developer", 65000));
        ems.addEmployee(new Employee("E003", "Alice Johnson", "Analyst", 60000));

        // Traverse employees
        System.out.println("Employee List:");
        ems.traverseEmployees();

        // Search employee
        System.out.println("\nSearching for employee E002:");
        System.out.println(ems.searchEmployeeById("E002"));

        // Delete employee
        System.out.println("\nDeleting employee E002:");
        ems.deleteEmployeeById("E002");

        // Traverse employees after deletion
        System.out.println("\nEmployee List after deletion:");
        ems.traverseEmployees();
    }
}
