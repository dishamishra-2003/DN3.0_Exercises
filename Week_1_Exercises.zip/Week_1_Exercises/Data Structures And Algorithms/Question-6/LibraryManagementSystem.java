import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class LibraryManagementSystem {

    // Book class with attributes bookId, title, and author
    public static class Book {
        private int bookId;
        private String title;
        private String author;

        public Book(int bookId, String title, String author) {
            this.bookId = bookId;
            this.title = title;
            this.author = author;
        }

        public int getBookId() {
            return bookId;
        }

        public String getTitle() {
            return title;
        }

        public String getAuthor() {
            return author;
        }

        @Override
        public String toString() {
            return "Book [bookId=" + bookId + ", title=" + title + ", author=" + author + "]";
        }
    }

    // Linear search to find books by title
    public static Book linearSearchByTitle(List<Book> books, String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    // Binary search to find books by title (assuming the list is sorted)
    public static Book binarySearchByTitle(List<Book> books, String title) {
        int left = 0;
        int right = books.size() - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = books.get(mid).getTitle().compareToIgnoreCase(title);

            if (comparison == 0) {
                return books.get(mid);
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        // Creating a list of books
        List<Book> books = new ArrayList<>();
        books.add(new Book(1, "The Catcher in the Rye", "J.D. Salinger"));
        books.add(new Book(2, "To Kill a Mockingbird", "Harper Lee"));
        books.add(new Book(3, "1984", "George Orwell"));
        books.add(new Book(4, "Pride and Prejudice", "Jane Austen"));
        books.add(new Book(5, "The Great Gatsby", "F. Scott Fitzgerald"));

        // Sort the list of books by title for binary search
        Collections.sort(books, Comparator.comparing(Book::getTitle));

        // Searching for a book by title using linear search
        String titleToSearch = "1984";
        Book foundBookLinear = linearSearchByTitle(books, titleToSearch);
        if (foundBookLinear != null) {
            System.out.println("Linear Search: Found book - " + foundBookLinear);
        } else {
            System.out.println("Linear Search: Book not found.");
        }

        // Searching for a book by title using binary search
        Book foundBookBinary = binarySearchByTitle(books, titleToSearch);
        if (foundBookBinary != null) {
            System.out.println("Binary Search: Found book - " + foundBookBinary);
        } else {
            System.out.println("Binary Search: Book not found.");
        }
    }
}
